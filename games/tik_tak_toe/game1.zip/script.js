/**
 * Neon Tic Tac Toe
 * Final Bug-Free JS Engine
 */

const game = (() => {
    // State
    let board = ['', '', '', '', '', '', '', '', ''];
    let currentPlayer = 'X';
    let gameActive = false;
    let mode = '1p'; // '1p' or '2p'
    let difficulty = 'easy'; // 'easy', 'medium', 'hard'
    let scores = { X: 0, O: 0, Draw: 0 };
    
    // AI Timing and State Flags
    let isAiThinking = false; 
    let aiTimeout = null;

    // Audio Context
    let audioCtx = null;
    let soundEnabled = true;

    // DOM Elements
    const screens = {
        start: document.getElementById('start-screen'),
        difficulty: document.getElementById('difficulty-screen'),
        game: document.getElementById('game-screen')
    };
    
    const cells = document.querySelectorAll('.cell');
    const turnIndicator = document.getElementById('turn-indicator');
    const scoreX = document.getElementById('score-x');
    const scoreO = document.getElementById('score-o');
    const scoreDraw = document.getElementById('score-draw');
    const modalOverlay = document.getElementById('modal-overlay');
    const modalTitle = document.getElementById('modal-title');
    const modalMsg = document.getElementById('modal-msg');
    const soundToggleBtn = document.getElementById('sound-toggle');

    const winningConditions = [
        [0, 1, 2], [3, 4, 5], [6, 7, 8], // Rows
        [0, 3, 6], [1, 4, 7], [2, 5, 8], // Cols
        [0, 4, 8], [2, 4, 6]             // Diags
    ];

    // Initialization
    function init() {
        cells.forEach(cell => {
            cell.addEventListener('click', handleCellClick);
        });
    }

    // --- Audio Engine (Synthesized) ---
    function initAudio() {
        if (!audioCtx && soundEnabled) {
            const AudioContext = window.AudioContext || window.webkitAudioContext;
            audioCtx = new AudioContext();
        }
    }

    function playSound(type) {
        if (!soundEnabled) return;
        initAudio();
        if (audioCtx.state === 'suspended') audioCtx.resume();

        const osc = audioCtx.createOscillator();
        const gainNode = audioCtx.createGain();
        osc.connect(gainNode);
        gainNode.connect(audioCtx.destination);

        const now = audioCtx.currentTime;

        if (type === 'click') {
            osc.type = 'sine';
            osc.frequency.setValueAtTime(400, now);
            osc.frequency.exponentialRampToValueAtTime(600, now + 0.1);
            gainNode.gain.setValueAtTime(0.5, now);
            gainNode.gain.exponentialRampToValueAtTime(0.01, now + 0.1);
            osc.start(now);
            osc.stop(now + 0.1);
        } else if (type === 'win') {
            osc.type = 'triangle';
            osc.frequency.setValueAtTime(300, now);
            osc.frequency.setValueAtTime(400, now + 0.1);
            osc.frequency.setValueAtTime(500, now + 0.2);
            osc.frequency.setValueAtTime(800, now + 0.3);
            gainNode.gain.setValueAtTime(0.5, now);
            gainNode.gain.linearRampToValueAtTime(0, now + 0.6);
            osc.start(now);
            osc.stop(now + 0.6);
        } else if (type === 'draw') {
            osc.type = 'square';
            osc.frequency.setValueAtTime(200, now);
            osc.frequency.linearRampToValueAtTime(150, now + 0.3);
            gainNode.gain.setValueAtTime(0.3, now);
            gainNode.gain.linearRampToValueAtTime(0, now + 0.3);
            osc.start(now);
            osc.stop(now + 0.3);
        }
    }

    function toggleSound() {
        soundEnabled = !soundEnabled;
        soundToggleBtn.innerHTML = soundEnabled ? '🔊 Sound ON' : '🔇 Sound OFF';
        if(soundEnabled) initAudio();
    }

    // --- UI Management ---
    function showScreen(screenId) {
        Object.values(screens).forEach(s => {
            s.classList.remove('active');
            s.style.display = 'none'; 
        });
        const activeScreen = document.getElementById(screenId);
        activeScreen.style.display = 'flex';
        setTimeout(() => activeScreen.classList.add('active'), 10);
    }

    function selectMode(selectedMode) {
        playSound('click');
        mode = selectedMode;
        if (mode === '1p') {
            showScreen('difficulty-screen');
        } else {
            startGame();
        }
    }

    function startGame(selectedDiff = 'easy') {
        playSound('click');
        difficulty = selectedDiff;
        resetMatch();
        showScreen('game-screen');
    }

    function updateTurnIndicator() {
        turnIndicator.textContent = `${currentPlayer}'s Turn`;
        turnIndicator.className = `turn-indicator glass-panel turn-${currentPlayer.toLowerCase()}`;
    }

    function updateScoresUI() {
        scoreX.textContent = scores.X;
        scoreO.textContent = scores.O;
        scoreDraw.textContent = scores.Draw;
    }

    // --- Core Game Logic ---
    function handleCellClick(e) {
        const cell = e.target;
        const index = parseInt(cell.getAttribute('data-index'));

        // Prevent click if cell is filled, game is over, or AI is thinking
        if (board[index] !== '' || !gameActive || isAiThinking) return;

        makeMove(index, currentPlayer);

        // Schedule AI Turn
        if (gameActive && mode === '1p' && currentPlayer === 'O') {
            isAiThinking = true; 
            aiTimeout = setTimeout(() => {
                if (gameActive) {
                    makeAIMove();
                }
                isAiThinking = false;
            }, 500);
        }
    }

    function makeMove(index, player) {
        board[index] = player;
        cells[index].textContent = player;
        cells[index].classList.add(player.toLowerCase(), 'occupied');
        playSound('click');

        checkResult();
        
        if (gameActive) {
            currentPlayer = currentPlayer === 'X' ? 'O' : 'X';
            updateTurnIndicator();
        }
    }

    function checkResult() {
        let roundWon = false;
        let winningTrio = [];

        for (let i = 0; i < winningConditions.length; i++) {
            const [a, b, c] = winningConditions[i];
            if (board[a] && board[a] === board[b] && board[a] === board[c]) {
                roundWon = true;
                winningTrio = [a, b, c];
                break;
            }
        }

        if (roundWon) {
            endGame(currentPlayer, winningTrio);
            return;
        }

        if (!board.includes('')) {
            endGame('Draw');
            return;
        }
    }

    function endGame(winner, winningTrio = []) {
        gameActive = false;
        
        if (winner === 'Draw') {
            scores.Draw++;
            playSound('draw');
            modalTitle.textContent = "It's a Draw!";
            modalTitle.className = "modal-title text-muted";
            modalMsg.textContent = "Nobody wins this round.";
        } else {
            scores[winner]++;
            playSound('win');
            winningTrio.forEach(index => cells[index].classList.add('win'));
            modalTitle.textContent = `${winner} Wins!`;
            modalTitle.className = `modal-title text-${winner.toLowerCase()}`;
            modalMsg.textContent = mode === '1p' && winner === 'O' ? "The AI outsmarted you." : `Player ${winner} takes the round!`;
        }

        updateScoresUI();
        setTimeout(() => modalOverlay.classList.add('active'), 800);
    }

    // --- AI Logic ---
    function makeAIMove() {
        let moveIndex;
        
        if (difficulty === 'easy') {
            moveIndex = getRandomMove();
        } else if (difficulty === 'medium') {
            moveIndex = Math.random() < 0.5 ? getRandomMove() : getBestMove();
        } else {
            moveIndex = getBestMove();
        }

        makeMove(moveIndex, 'O');
    }

    function getRandomMove() {
        const available = board.map((val, idx) => val === '' ? idx : null).filter(val => val !== null);
        return available[Math.floor(Math.random() * available.length)];
    }

    function getBestMove() {
        return minimax(board, 'O').index;
    }

    function minimax(newBoard, player) {
        const availSpots = newBoard.map((val, idx) => val === '' ? idx : null).filter(val => val !== null);

        if (checkWinCondition(newBoard, 'X')) return { score: -10 };
        else if (checkWinCondition(newBoard, 'O')) return { score: 10 };
        else if (availSpots.length === 0) return { score: 0 };

        const moves = [];

        for (let i = 0; i < availSpots.length; i++) {
            const move = {};
            move.index = availSpots[i];
            newBoard[availSpots[i]] = player; 

            if (player === 'O') {
                const result = minimax(newBoard, 'X');
                move.score = result.score;
            } else {
                const result = minimax(newBoard, 'O');
                move.score = result.score;
            }

            newBoard[availSpots[i]] = ''; 
            moves.push(move);
        }

        let bestMove;
        if (player === 'O') {
            let bestScore = -10000;
            for (let i = 0; i < moves.length; i++) {
                if (moves[i].score > bestScore) {
                    bestScore = moves[i].score;
                    bestMove = i;
                }
            }
        } else {
            let bestScore = 10000;
            for (let i = 0; i < moves.length; i++) {
                if (moves[i].score < bestScore) {
                    bestScore = moves[i].score;
                    bestMove = i;
                }
            }
        }
        return moves[bestMove];
    }

    function checkWinCondition(testBoard, player) {
        return winningConditions.some(combo => {
            return combo.every(index => testBoard[index] === player);
        });
    }

    // --- Reset & Controls ---
    function resetMatch() {
        // Clear any pending AI timeouts if reset mid-way
        if (aiTimeout) clearTimeout(aiTimeout);
        isAiThinking = false;
        
        board = ['', '', '', '', '', '', '', '', ''];
        currentPlayer = 'X';
        gameActive = true;
        
        cells.forEach(cell => {
            cell.textContent = '';
            cell.className = 'cell'; 
        });
        
        updateTurnIndicator();
    }

    function closeModalAndReset() {
        playSound('click');
        modalOverlay.classList.remove('active');
        resetMatch();
    }

    function resetScores() {
        playSound('click');
        scores = { X: 0, O: 0, Draw: 0 };
        updateScoresUI();
        resetMatch();
    }

    function quitGame() {
        playSound('click');
        resetScores();
        showScreen('start-screen');
    }

    // Public API
    init();
    
    return {
        selectMode,
        startGame,
        toggleSound,
        showScreen,
        resetMatch,
        resetScores,
        closeModalAndReset,
        quitGame
    };
})();