let secretNumber = Math.floor(Math.random() * 100) + 1;
let attempts = 0;

function checkGuess() {
    const guess = Number(document.getElementById("guessInput").value);
    const message = document.getElementById("message");

    if (!guess) {
        message.textContent = "Please enter a number!";
        return;
    }

    attempts++;
    document.getElementById("attempts").textContent = attempts;

    if (guess === secretNumber) {
        message.textContent = `🎉 Correct! The number was ${secretNumber}`;
    } else if (guess < secretNumber) {
        message.textContent = "📈 Too low!";
    } else {
        message.textContent = "📉 Too high!";
    }
}

function newGame() {
    secretNumber = Math.floor(Math.random() * 100) + 1;
    attempts = 0;
    document.getElementById("attempts").textContent = "0";
    document.getElementById("message").textContent = "";
    document.getElementById("guessInput").value = "";
}